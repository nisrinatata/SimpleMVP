
package com.example.mvp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;


import com.example.mvp.Interactor.LoginInteractor;
import com.example.mvp.Presenter.LoginPresenter;
import com.example.mvp.View.LoginView;


public class MainActivity extends AppCompatActivity implements LoginView {


    EditText edt_user, edt_pass;
    ProgressBar progressbar_login;

    LoginPresenter loginPresenter;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        loginPresenter = new LoginPresenter(this, new LoginInteractor());
    }

    void initViews() {
        edt_user = findViewById(R.id.edt_user);
        edt_pass = findViewById(R.id.edt_pass);
        progressbar_login = findViewById(R.id.progress_login);
    }

    public void loginMe(View view) {
        showProgressbar();

        loginPresenter.validateCredentials(edt_user.getText().toString().trim(), edt_user.getText().toString().trim());
    }

    @Override
    public void setUsernameError() {
        hideProgressbar();
        edt_user.setError("Username can't be empty!");

    }

    @Override
    public void setPasswordError() {

        hideProgressbar();
        edt_pass.setError("password can't be empty!");
    }

    @Override
    public void onLoginSuccess(String username) {


        Intent intent = new Intent(this, WelcomeActivity.class);
        intent.putExtra("username", username);
        startActivity(intent);

    }

    @Override
    public void onLoginError() {
        hideProgressbar();

        Toast.makeText(this, "username or password doesn't match", Toast.LENGTH_LONG).show();
    }

    @Override
    public void showProgressbar() {

        progressbar_login.setVisibility(View.VISIBLE);

    }

    @Override
    public void hideProgressbar() {

        progressbar_login.setVisibility(View.GONE);

    }
}
